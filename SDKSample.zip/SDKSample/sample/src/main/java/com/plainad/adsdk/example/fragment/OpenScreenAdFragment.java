package com.plainad.adsdk.example.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.plainad.adsdk.example.OpenScreenActivity;
import com.plainad.adsdk.example.R;
import com.plainad.adsdk.example.SampleApplication;
import com.plainad.adsdk.example.config.Config;
import com.plainad.adsdk.example.listener.MyCTAdEventListener;
import com.plainad.base.core.AdvanceNative;
import com.plainad.base.core.PANative;
import com.plainad.base.core.PlainAdSDK;
import com.plainad.base.vo.AdsNativeVO;

public class OpenScreenAdFragment extends Fragment {

    private TextView adStatusTextView;
    private Button loadButton;
    private Button showButton;

    private boolean preloadResult;

    private AdsNativeVO adsNativeVO = null;

    Handler handler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_open_screen, null);
        initView(view);
        return view;
    }


    private void initView(View view) {

        adStatusTextView = (TextView) view.findViewById(R.id.statusLabel);

        loadButton = (Button) view.findViewById(R.id.loadButton);
        loadButton.setText("LOAD AD");
        showButton = (Button) view.findViewById(R.id.showButton);
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadAd();
            }
        });

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAd();
            }
        });

    }


    private void showAd() {
        if (preloadResult && adsNativeVO != null) {
            OpenScreenActivity.showMe(getContext(), adsNativeVO);
        }
    }


    private static final String TAG = "OpenScreenAdFragment";

    public void loadAd() {

        log("OpenScreen Ad Loading...");
        // 预加载
        preloadResult = PlainAdSDK.preloadNativeAd(Config.slotIdNative, getContext());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loading();
            }
        }, 3000);

    }

    public void loading() {
        if (preloadResult) {
            PlainAdSDK.getNativeAdForCache(Config.slotIdNative, new MyCTAdEventListener() {
                @Override
                public void onReceiveAdSucceed(PANative result) {
                    super.onReceiveAdSucceed(result);
                }

                @Override
                public void onReceiveAdVoSucceed(AdsNativeVO result) {
                    //show
                    log("OpenScreen Ad Loaded.");
                    adsNativeVO = result;
                    super.onReceiveAdVoSucceed(result);
                }

                @Override
                public void onReceiveAdFailed(PANative result) {
                    preloadResult = false;
                    Log.w(TAG, "onReceiveAdFailed: " + result.getErrorsMsg());
                    log("OpenScreen ad failed to load with error msg:: " +
                            result.getErrorsMsg());
                    super.onReceiveAdFailed(result);
                }
            });
        } else {
            PlainAdSDK.getNativeAd(Config.slotIdNative, getContext(), new MyCTAdEventListener() {
                @Override
                public void onReceiveAdVoSucceed(AdsNativeVO result) {
                    //show
                    log("OpenScreen Ad Loaded.");
                    adsNativeVO = result;
                    super.onReceiveAdVoSucceed(result);
                }

                @Override
                public void onReceiveAdFailed(PANative result) {
                    Log.w(TAG, "onReceiveAdFailed: " + result.getErrorsMsg());
                    log("OpenScreen ad failed to load with error msg:: " +
                            result.getErrorsMsg());
                    super.onReceiveAdFailed(result);
                }
            });
        }
    }

    private void log(final String s) {
        if (adStatusTextView != null) {
            Activity activity = getActivity();
            if (!isDetached() && activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adStatusTextView.setText(s);
                    }
                });
            }

        }
        Log.w(TAG, "log: " + s);
    }
}
