package com.plainad.adsdk.example.fragment;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.plainad.adsdk.example.R;
import com.plainad.adsdk.example.config.Config;
import com.plainad.adsdk.example.listener.MyPlainAdEventListener;
import com.plainad.base.callback.VideoAdLoadListener;
import com.plainad.base.core.PAError;
import com.plainad.base.core.PAVideo;
import com.plainad.base.core.PlainAdSDK;
import com.plainad.video.core.RewardedVideoAdListener;
import com.plainad.video.core.PlainAdVideo;

public class RewardVideoAdFragment extends Fragment {

    private static final String TAG = "RewardVideoAdFragment";
    private TextView adStatusTextView, interstitialStatus;
    private PAVideo video;
    private com.plainad.base.core.PANative interstitial;
    private Button loadButton, showButton, loadInterstitialButton, showInterstitialButton;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reward_video, null);
        initView(view);
        return view;
    }


    private void initView(View view) {
        adStatusTextView = view.findViewById(R.id.statusLabel);
        interstitialStatus = view.findViewById(R.id.interstitialStatusLabel);
        loadButton = view.findViewById(R.id.loadButton);
        showButton = view.findViewById(R.id.showButton);
        loadInterstitialButton = view.findViewById(R.id.loadInterstitialButton);
        showInterstitialButton = view.findViewById(R.id.showInterstitialButton);

        PlainAdVideo.setUserId("custom_id");

        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadRewardedVideo();
            }
        });

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRewardedVideo();
            }
        });

        loadInterstitialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadInterstitial();
            }
        });

        showInterstitialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInterstitial();
            }
        });
    }


    private void showInterstitial() {
        if (PlainAdSDK.isInterstitialAvailable(interstitial)) {
            logi("Ready to load.", true);
            PlainAdSDK.showInterstitialAd(interstitial);
        } else {
            logi("Interstitial Is Not Available", true);
        }
    }


    private void loadInterstitial() {
        logi("Interstitial Loading...", true);
        showInterstitialButton.setEnabled(false);
        // 获取插屏广告，返回一个含有广告的容器
        PlainAdSDK.preloadInterstitialAd(getContext(), Config.slotIdInterstitial,
                new MyPlainAdEventListener() {

                    @Override
                    public void onShowSucceed(com.plainad.base.core.PANative result) {
                        super.onShowSucceed(result); // 展示成功
                    }


                    @Override
                    public void onLandPageShown(com.plainad.base.core.PANative result) {
                        super.onLandPageShown(result);
                        Log.e(TAG, "onLandpageShown: ");
                    }

                    @Override
                    public void onReceiveAdSucceed(com.plainad.base.core.PANative result) {              //在广告加载成功之后再show,不然会出一个空白
                        if (result != null && result.isLoaded()) {
                            interstitial = result;
                            showInterstitialButton.setEnabled(true);
                            logi("Interstitial Loaded.", false);
                            Log.e(TAG, "onReceiveAdSucceed");
                        }

                        super.onReceiveAdSucceed(result);
                    }


                    @Override
                    public void onReceiveAdFailed(com.plainad.base.core.PANative error) {
                        Log.w(TAG, "onReceiveAdFailed: " + error.getErrorsMsg());
                        logi("Interstitial ad failed : " +
                                error.getErrorsMsg(), true);
                        showInterstitialButton.setEnabled(false);
                        super.onReceiveAdFailed(error);
                    }


                    @Override
                    public void onAdClosed(com.plainad.base.core.PANative result) {
                        super.onAdClosed(result);
                        Log.e(TAG, "onAdClosed:");
                        interstitial = null;
                    }
                });

    }


    private void showRewardedVideo() {
        if (PlainAdVideo.isRewardedVideoAvailable(video)) {
            log("Ready to load.", true);
            PlainAdVideo.showRewardedVideo(video, new RewardedVideoAdListener() {
                @Override
                public void videoStart() {
                    Log.e(TAG, "videoStart: ");
                }


                @Override
                public void videoFinish() {
                    Log.e(TAG, "videoFinish: ");
                }


                @Override
                public void videoError(Exception e) {
                    Log.e(TAG, "videoError: ");
                }


                @Override
                public void videoClosed() {
                    Log.e(TAG, "videoClosed: ");
                }

                @Override
                public void videoClicked() {
                    Log.e(TAG, "videoClicked: ");
                }

                @Override
                public void videoRewarded(String rewardName, String
                        rewardAmount) {
                    Log.e(TAG, "videoRewarded: ");
                }
            });
        } else {
            log("Cannot Show Rewarded Video", true);
        }
    }


    private void loadRewardedVideo() {
        log("RewardedVideo loading...", true);
        showButton.setEnabled(false);
        PlainAdVideo.preloadRewardedVideo(getContext(), Config.slotIdReward,
                new VideoAdLoadListener() {
                    @Override
                    public void onVideoAdLoadSucceed(PAVideo videoAd) {
                        video = videoAd;
                        showButton.setEnabled(true);
                        log("RewardedVideo loaded.", false);
                        Log.w(TAG, "onVideoAdLoadSucceed: ");
                    }


                    @Override
                    public void onVideoAdLoadFailed(PAError error) {
                        Log.w(TAG, "onVideoAdLoadFailed: " + error.getMsg());
                        log("RewardedVideo failed : " + error.getMsg(), true);
                        showButton.setEnabled(false);
                    }
                });
    }


    private void logi(final String s, final boolean error) {
        if (interstitialStatus != null) {
            Activity activity = getActivity();
            if (!isDetached() && activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        interstitialStatus.setTextColor(error ? Color.RED : Color.GREEN);
                        interstitialStatus.setText(s);
                    }
                });
            }

        }
        Log.w(TAG, "log interstitial : " + s);
    }


    private void log(final String s, final boolean error) {
        if (adStatusTextView != null) {
            Activity activity = getActivity();
            if (!isDetached() && activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adStatusTextView.setTextColor(error ? Color.RED : Color.GREEN);
                        adStatusTextView.setText(s);
                    }
                });
            }

        }
        Log.w(TAG, "log rewarded video : " + s);
    }

}