package com.plainad.adsdk.example;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.plainad.base.core.AdvanceNative;
import com.plainad.base.utils.ContextHolder;
import com.plainad.base.vo.AdsNativeVO;

import static android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;

public class OpenScreenActivity extends Activity {

    private boolean cancelable;

    public static void showMe(Context context, AdsNativeVO adsNativeVO) {
        Intent intent = new Intent(context, OpenScreenActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                Intent.FLAG_ACTIVITY_NO_ANIMATION);
        intent.putExtra("adsNative", adsNativeVO);
        ContextHolder.getGlobalAppContext().startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        super.onCreate(savedInstanceState);
        boolean mVertical = getResources().getConfiguration().orientation ==
                SCREEN_ORIENTATION_PORTRAIT;
        int orientation = mVertical
                ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        setRequestedOrientation(orientation);
        AdsNativeVO adsNativeVO = (AdsNativeVO) getIntent().getSerializableExtra("adsNative");
        if (adsNativeVO == null) {
            finish();
        }
        setContentView(R.layout.activity_open_screen);

        final AdvanceNative ctAdvanceNative = new AdvanceNative(this);
        ctAdvanceNative.setNativeVO(adsNativeVO);
        showAd(ctAdvanceNative);
    }

    private void showAd(final AdvanceNative ctAdvanceNative) {

        SimpleDraweeView img = findViewById(R.id.iv_img);
        SimpleDraweeView icon = findViewById(R.id.iv_icon);
        TextView title = findViewById(R.id.tv_title);
        TextView desc = findViewById(R.id.tv_desc);
        TextView click = findViewById(R.id.bt_click);
        SimpleDraweeView ad_choice_icon = findViewById(R.id.ad_choice_icon);

        if (ctAdvanceNative.getImageFile() == null) {
            //if no cache, get image from url
            img.setImageURI(Uri.parse(ctAdvanceNative.getImageUrl()));
        } else {
            //loaded from cache
            img.setImageURI(Uri.fromFile(ctAdvanceNative.getImageFile()));
        }

        if (ctAdvanceNative.getIconFile() == null) {
            icon.setImageURI(Uri.parse(ctAdvanceNative.getIconUrl()));
        } else {
            //loaded from cache
            icon.setImageURI(Uri.fromFile(ctAdvanceNative.getIconFile()));
        }

        title.setText(ctAdvanceNative.getTitle());
        desc.setText(ctAdvanceNative.getDesc());
        click.setText(ctAdvanceNative.getButtonStr());
        ad_choice_icon.setImageURI(ctAdvanceNative.getAdChoiceIconUrl());

        //只是注册点击区域,调此处设置
        ctAdvanceNative.registeADClickArea(getWindow().getDecorView());

        ad_choice_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String linkUrl = ctAdvanceNative.getAdChoiceLinkUrl();
                if (TextUtils.isEmpty(linkUrl)) {
                    Toast.makeText(getBaseContext(), "adChoiceLinkUrl is null", Toast.LENGTH_LONG).show();
                    return;
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl));
                browserIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (browserIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(browserIntent);
                }
            }
        });
        findViewById(R.id.close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (cancelable) {
            super.onBackPressed();
        }
    }
}
