package com.plainad.adsdk.example.bean;

import com.plainad.video.core.PANativeVideo;

/**
 * Created by huangdong on 16/8/18.
 */
public class News {

    public PANativeVideo ctNativeVideo;
    public com.plainad.base.core.AdvanceNative ctAdvanceNative;
    public String iconUrl;
    public String title;
    public String desc;
    public String choiceUrl;
    public String buttonStr;
    public boolean isAds = false;

}
