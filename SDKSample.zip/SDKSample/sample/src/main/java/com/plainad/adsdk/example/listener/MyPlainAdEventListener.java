package com.plainad.adsdk.example.listener;

import android.util.Log;
import android.widget.Toast;

import com.plainad.base.callback.AdEventListener;
import com.plainad.base.core.PANative;
import com.plainad.base.vo.AdsVO;

public class MyPlainAdEventListener extends AdEventListener {

    @Override
    public void onReceiveAdSucceed(PANative result) {
        showMsg("onReceiveAdSucceed");
    }

    @Override
    public void onReceiveAdVoSucceed(AdsVO result) {
        showMsg("onReceiveAdVoSucceed");
    }

    @Override
    public void onShowSucceed(PANative result) {
        showMsg("onShowSucceed");
    }

    @Override
    public void onReceiveAdFailed(PANative result) {
        showMsg(result.getErrorsMsg());
        Log.i("sdksample", "==error==" + result.getErrorsMsg());
    }

    @Override
    public void onLandPageShown(PANative result) {
        showMsg("onLandPageShown");
    }

    @Override
    public void onAdClicked(PANative result) {
        showMsg("onAdClicked");
    }

    @Override
    public void onAdClosed(PANative result) {
        showMsg("onAdClosed");
    }


    private void showMsg(String msg) {
        showToast(msg);
    }


    public static void showToast(String text) {
        // Toast.makeText(SampleApplication.context, text, Toast.LENGTH_SHORT).show();
    }


    private static Toast toast;

}
