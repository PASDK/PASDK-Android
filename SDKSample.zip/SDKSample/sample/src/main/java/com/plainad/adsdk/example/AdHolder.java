package com.plainad.adsdk.example;

/**
 * Created by Vincent
 *
 */
public class AdHolder {
    public static com.plainad.base.vo.AdsNativeVO adNativeVO = null;

}
