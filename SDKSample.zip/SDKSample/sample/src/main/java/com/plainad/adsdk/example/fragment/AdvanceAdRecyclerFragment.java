package com.plainad.adsdk.example.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.plainad.adsdk.example.R;
import com.plainad.adsdk.example.SampleApplication;
import com.plainad.adsdk.example.Utils;
import com.plainad.adsdk.example.adapter.NormalRecyclerViewAdapter;
import com.plainad.adsdk.example.bean.News;
import com.plainad.adsdk.example.model.AdsModel;

import java.util.List;

/**
 * Created by huangdong on 16/8/23.
 */
public class AdvanceAdRecyclerFragment extends Fragment implements AdsModel.AdsModelListener {

    private View view;
    private RecyclerView mRecyclerView;
    private NormalRecyclerViewAdapter normalRecyclerViewAdapter;
    private AdsModel adsModel;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_advance_ad_recycler, null);
        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(
            new LinearLayoutManager(SampleApplication.context));//这里用线性显示 类似于listview

        normalRecyclerViewAdapter = new NormalRecyclerViewAdapter(SampleApplication.context);
        mRecyclerView.setAdapter(normalRecyclerViewAdapter);

        //获取数据
        adsModel = AdsModel.getAdsModel();
        adsModel.loadCommonData(6);
        adsModel.loadSmallAds(3);

        super.onActivityCreated(savedInstanceState);
    }


    @Override
    public void onResume() {
        super.onResume();
        refreshUI();
        adsModel.registerListener(this);
    }


    @Override
    public void onPause() {
        super.onPause();
        adsModel.removeListener(this);
    }


    @Override
    public void onUpdate() {

        refreshUI();
    }


    public void refreshUI() {

        List<News> commonList = adsModel.getCommonList();

        List<News> smallAdsList = adsModel.getSmallList();

        List<News> list = Utils.combineAdAndContent(commonList, smallAdsList, 2);

        normalRecyclerViewAdapter.setDate(list);

    }

}
