package com.plainad.adsdk.example.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.plainad.adsdk.example.R;
import com.plainad.adsdk.example.config.Config;
import com.plainad.adsdk.example.listener.MyCTAdEventListener;
import com.plainad.base.core.PlainAdSDK;
import com.plainad.base.enums.AdSize;

import java.util.ArrayList;

/**
 * Created by longzhang on 7/26/16.
 */
public class AdListFragment extends Fragment {

    private ListView adList;
    private MyApdater myApdater;
    private Context context;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.ad_list_layout, null);
        context = getContext();
        initView(view);
        return view;
    }


    private void initView(View view) {
        adList = (ListView) view.findViewById(R.id.ad_lv);
        myApdater = new MyApdater();
        adList.setAdapter(myApdater);

        loadData();
    }


    public void loadData() {

        for (int i = 0; i < 8; i++) {
            if (i % 2 == 0) {
                final int index = i;
                PlainAdSDK.getBannerAd(context, Config.slotIdBanner, AdSize.AD_SIZE_300X250,
                        new MyCTAdEventListener() {
                            @Override
                            public void onReceiveAdSucceed(com.plainad.base.core.PANative result) {
                                myApdater.addData(result, index);
                            }


                            @Override
                            public void onReceiveAdFailed(com.plainad.base.core.PANative result) {
                                super.onReceiveAdFailed(result);
                            }
                        });
            } else {
                myApdater.addData(null);
            }
        }

    }


    class MyApdater extends BaseAdapter {

        ArrayList<com.plainad.base.core.PANative> dataList = new ArrayList<>();

        private int adType = 1;
        private int noAd = 0;


        @Override
        public int getCount() {
            return dataList.size();
        }


        @Override
        public com.plainad.base.core.PANative getItem(int i) {
            return dataList.get(i);
        }


        @Override
        public long getItemId(int i) {
            return i;
        }


        @Override
        public int getItemViewType(int position) {
            if (getItem(position) != null) {
                return adType;
            } else {
                return noAd;
            }
        }


        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            if (getItemViewType(i) == adType) {
                com.plainad.base.core.PANative dataItem = getItem(i);
                removeFromParent(dataItem);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, dp2px(getActivity(), 60));
                FrameLayout frameLayout = new FrameLayout(getContext());
                frameLayout.addView(dataItem, lp);
                view = frameLayout;
            } else {
                view = LayoutInflater.from(getContext()).inflate(R.layout.item_layout, null);
                TextView titleTV = (TextView) view.findViewById(R.id.title);
                titleTV.setText("title");
            }

            return view;
        }


        public void addData(com.plainad.base.core.PANative item) {
            dataList.add(item);
            notifyDataSetChanged();
        }


        public void addData(com.plainad.base.core.PANative item, int index) {
            if (index >= 0 && index < dataList.size()) {
                dataList.add(index, item);
                notifyDataSetChanged();
            }
        }
    }


    public static void removeFromParent(View v) {
        if (v == null) {
            return;
        }

        ViewParent vp = v.getParent();
        if (vp == null) {
            return;
        }

        if (vp instanceof AdapterView) {
            //removeAllViews() is not supported in AdapterView
            return;
        }
        ((ViewGroup) vp).removeAllViews();
    }


    public static int dp2px(Context context, int dp) {
        return (int) context.getResources().getDisplayMetrics().density * dp;
    }

}
