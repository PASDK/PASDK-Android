package com.plainad.adsdk.example.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.plainad.adsdk.example.R;
import com.plainad.adsdk.example.config.Config;
import com.plainad.base.core.PAVideo;
import com.facebook.drawee.view.SimpleDraweeView;
import com.plainad.base.core.PAError;
import com.plainad.video.core.PANativeVideo;
import com.plainad.video.core.PlainAdVideo;

/**
 * Created by huangdong on 18/7/11.
 *
 */
public class NativeVideoFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = "NativeVideoFragment";
    private Context context;
    private RelativeLayout rl_container;
    private PANativeVideo ctNativeVideo;
    private Button load;
    private Button showAuto;
    private Button showManual;
    private Button play;
    private Button stop;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_native_video, null);
        context = getContext();
        rl_container = view.findViewById(R.id.rl_container);

        load = view.findViewById(R.id.v_load);
        showAuto = view.findViewById(R.id.v_show_1);
        showManual = view.findViewById(R.id.v_show_2);
        play = view.findViewById(R.id.v_play);
        stop = view.findViewById(R.id.v_stop);

        showAuto.setEnabled(false);
        showManual.setEnabled(false);
        play.setEnabled(false);
        stop.setEnabled(false);

        load.setOnClickListener(this);
        showAuto.setOnClickListener(this);
        showManual.setOnClickListener(this);
        play.setOnClickListener(this);
        stop.setOnClickListener(this);

        return view;
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.v_load:
                loadNativeVideo(context);
                play.setEnabled(false);
                stop.setEnabled(false);
                break;
            case R.id.v_show_1:
                showNativeVideo(ctNativeVideo, true);
                load.setEnabled(true);
                showAuto.setEnabled(false);
                showManual.setEnabled(false);
                break;
            case R.id.v_show_2:
                showNativeVideo(ctNativeVideo, false);
                load.setEnabled(true);
                showAuto.setEnabled(false);
                showManual.setEnabled(false);
                play.setEnabled(true);
                stop.setEnabled(true);
                break;
            case R.id.v_play:
                playNativeVideo(ctNativeVideo);
                break;
            case R.id.v_stop:
                stopNativeVideo(ctNativeVideo);
                break;
        }
    }


    private void loadNativeVideo(final Context context) {

        PlainAdVideo.getNativeVideo(context, Config.slotIdNativeVideo, new com.plainad.base.callback.VideoAdLoadListener() {

            @Override
            public void onVideoAdLoadSucceed(PAVideo video) {
                Toast.makeText(context, "onVideoAdLoadSucceed", Toast.LENGTH_SHORT).show();
                ctNativeVideo = (PANativeVideo) video;
                showNativeVideo(ctNativeVideo, true);
                // load.setEnabled(false);
                showAuto.setEnabled(true);
                showManual.setEnabled(true);
            }


            @Override
            public void onVideoAdLoadFailed(PAError error) {
                Toast.makeText(context, "onVideoAdLoadFailed:: " + error.getMsg(),
                    Toast.LENGTH_SHORT).show();
            }
        });

    }


    private void showNativeVideo(final PANativeVideo ctNativeVideo, boolean autoPlay) {
        if (ctNativeVideo == null) {
            Toast.makeText(context, "play failed.", Toast.LENGTH_SHORT).show();
            return;
        }

        ViewGroup videoLayout = (ViewGroup) View.inflate(context, R.layout.native_video_layout,
            null);

        if (!autoPlay) {
            ctNativeVideo.setAutoPlayEnabled(false);
        }
        ctNativeVideo.setWWANPlayEnabled(false);

        TextView video_title = videoLayout.findViewById(R.id.video_title);
        RelativeLayout video_container = videoLayout.findViewById(R.id.video_container);
        SimpleDraweeView video_choice = videoLayout.findViewById(R.id.video_choice);
        TextView video_desc = videoLayout.findViewById(R.id.video_desc);
        TextView video_button = videoLayout.findViewById(R.id.video_button);

        video_title.setText(ctNativeVideo.getTitle());
        video_container.addView(ctNativeVideo.getNativeVideoAdView());
        video_choice.setImageURI(Uri.parse(ctNativeVideo.getAdChoiceIconUrl()));
        video_desc.setText(Html.fromHtml(ctNativeVideo.getDesc()));
        video_button.setText(ctNativeVideo.getButtonStr());

        ctNativeVideo.registerForTracking(videoLayout, new com.plainad.video.core.NativeVideoAdListener() {
            @Override
            public void videoStart() {
                Log.i(TAG, "videoStart: >>>>>>>>>>>>>>>>>>>>");
            }


            @Override
            public void videoFinish() {
                Log.i(TAG, "videoFinish: >>>>>>>>>>>>>>>>>>>>");
                play.setEnabled(false);
                stop.setEnabled(false);
            }


            @Override
            public void videoClicked() {
                Log.i(TAG, "videoClicked: >>>>>>>>>>>>>>>>>>>>");
            }


            @Override
            public void videoError(Exception e) {
                Log.i(TAG, "videoError: >>>>>>>>>>>>>>>>>>>>" + e.getMessage());
            }
        });

        video_choice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String linkUrl = ctNativeVideo.getAdChoiceLinkUrl();
                if (TextUtils.isEmpty(linkUrl)) {
                    Toast.makeText(getContext(), "adChoiceLinkUrl is null", Toast.LENGTH_LONG).show();
                    return;
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl));
                browserIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (browserIntent.resolveActivity(getContext().getPackageManager()) != null) {
                    startActivity(browserIntent);
                }
            }
        });

        rl_container.removeAllViews();
        rl_container.addView(videoLayout);
    }


    public void playNativeVideo(PANativeVideo ctNativeVideo) {
        com.plainad.video.view.NativeVideoAdView nativeVideoAdView = ctNativeVideo.getNativeVideoAdView();
        nativeVideoAdView.start();
    }


    public void stopNativeVideo(PANativeVideo ctNativeVideo) {
        com.plainad.video.view.NativeVideoAdView nativeVideoAdView = ctNativeVideo.getNativeVideoAdView();
        nativeVideoAdView.pause();
    }

}
