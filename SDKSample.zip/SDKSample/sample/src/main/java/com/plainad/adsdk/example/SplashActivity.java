package com.plainad.adsdk.example;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.plainad.adsdk.example.config.Config;
import com.plainad.adsdk.example.listener.MyPlainAdEventListener;
import com.plainad.base.core.PANative;
import com.plainad.base.core.PlainAdSDK;
import com.plainad.base.core.SplashView;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

/**
 * Created by huangdong on 17/4/13.
 */

public class SplashActivity extends Activity {


    private final static String TAG = "SplashActivity";

    private CountDownTimer timer;

    public static void showMe(Context context) {
        Intent intent = new Intent(context, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                Intent.FLAG_ACTIVITY_NO_ANIMATION);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        loadAd();

        timer = new CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                finish();
            }
        };
        timer.start();
    }

    private void show() {
        PlainAdSDK.showSplashAd(Config.slotIdNative, new MyPlainAdEventListener() {

            @Override
            public void onReceiveAdFailed(PANative result) {
                Log.e(TAG, "onReceiveAdFailed errorMsg=" + result.getErrorsMsg());
            }

            @Override
            public void onShowSucceed(PANative result) {
                Log.d(TAG, "onShowSucceed");
                if (result != null) {
                    SplashView splashView = (SplashView) result;

                    /*
                     * There are two ways to add a custom view
                     * inflate SplashView.getCustomParentView() or SplashView.addCustomView(view)
                     */
                    //1
                    //LayoutInflater.from(getContext()).inflate(R.layout.custom_splash_layout, splashView.getCustomParentView(), true);

                    //2
                    LinearLayout linearLayout = new LinearLayout(result.getContext());
                    linearLayout.setGravity(Gravity.CENTER);
                    linearLayout.setBackgroundColor(Color.WHITE);
                    linearLayout.setLayoutParams(new ViewGroup.LayoutParams(MATCH_PARENT, Utils.dpToPx(100)));
                    TextView textView = new TextView(result.getContext());
                    textView.setText("custom");
                    textView.setTextSize(22);
                    linearLayout.addView(textView, new ViewGroup.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
                    linearLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Toast.makeText(getBaseContext(), "custom", Toast.LENGTH_SHORT).show();
                        }
                    });
                    splashView.addCustomView(linearLayout);
                }
            }

            @Override
            public void onLandPageShown(PANative result) {
                Log.d(TAG, "onLandPageShown");
            }

            @Override
            public void onAdClicked(PANative result) {
                Log.d(TAG, "onAdClicked");
            }

            @Override
            public void onAdClosed(PANative result) {
                Log.d(TAG, "onAdClosed");
            }
        });
    }


    public void loadAd() {

        // 预加载
        PlainAdSDK.preloadSplashAd(this, Config.slotIdNative, new MyPlainAdEventListener() {


            @Override
            public void onReceiveAdSucceed(PANative result) {
                Log.d(TAG, "Splash Ad Loaded.");
                if (!isFinishing()) {
                    show();
                    finish();
                }
            }

            @Override
            public void onReceiveAdFailed(PANative result) {
                if (result != null && result.getErrorsMsg() != null)
                    Log.e(TAG, "onReceiveAdFailed errorMsg=" + result.getErrorsMsg());
                if (!isFinishing()) {
                    finish();
                }
            }


        });

    }

    @Override
    protected void onDestroy() {
        if (timer != null) {
            timer.cancel();
        }
        super.onDestroy();
    }
}
