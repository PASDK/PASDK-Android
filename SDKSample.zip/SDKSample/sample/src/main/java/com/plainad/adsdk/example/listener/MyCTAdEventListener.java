package com.plainad.adsdk.example.listener;

import android.util.Log;
import android.widget.Toast;

import com.plainad.base.callback.AdEventListener;

public class MyCTAdEventListener extends AdEventListener {

    @Override
    public void onReceiveAdSucceed(com.plainad.base.core.PANative result) {
        showMsg("onReceiveAdSucceed");
    }

    @Override
    public void onReceiveAdVoSucceed(com.plainad.base.vo.AdsNativeVO result) {
        showMsg("onReceiveAdVoSucceed");
    }

    @Override
    public void onInterstitialLoadSucceed(com.plainad.base.core.PANative result) {
        showMsg("onInterstitialLoadSucceed");
    }

    @Override
    public void onReceiveAdFailed(com.plainad.base.core.PANative result) {
        showMsg(result.getErrorsMsg());
        Log.i("sdksample", "==error==" + result.getErrorsMsg());
    }

    @Override
    public void onLandpageShown(com.plainad.base.core.PANative result) {
        showMsg("onLandpageShown");
    }

    @Override
    public void onAdClicked(com.plainad.base.core.PANative result) {
        showMsg("onAdClicked");
    }

    @Override
    public void onAdClosed(com.plainad.base.core.PANative result) {
        showMsg("onAdClosed");
    }


    private void showMsg(String msg) {
        showToast(msg);
    }


    public static void showToast(String text) {
        // Toast.makeText(SampleApplication.context, text, Toast.LENGTH_SHORT).show();
    }


    private static Toast toast;

}
