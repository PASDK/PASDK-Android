package com.plainad.adsdk.example;

import android.support.test.espresso.DataInteraction;
import android.support.test.espresso.Espresso;
import android.support.test.espresso.assertion.ViewAssertions;
import android.support.test.filters.LargeTest;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import com.plainad.adsdk.example.utils.Constants;
import com.plainad.adsdk.example.utils.PowersUtil;
import com.plainad.adsdk.example.utils.RepeatRule;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.hasChildCount;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;

/**
 * Created by tujiantao on 2018/3/5.
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class NativeAdTest {

    private final static String TAG = "NativeAdTest";
//
    @Rule
    public RepeatRule repeatRule = new RepeatRule();

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity
            .class);


    private SimpleCountingIdlingResource getAdIdlingResource;

    @BeforeClass
    public static void startClass(){
    }

    @Before
    public void start() throws InterruptedException {

        final MainActivity activity = mActivityTestRule.getActivity();
        if (!PowersUtil.getScreenOn(activity) || PowersUtil.getLockScreenOn(activity)) {//解锁屏幕
            PowersUtil.wakeUpAndUnlock(activity);
        }
        Thread.sleep(2000);
        DataInteraction appCompatTextView = onData(anything())
                .inAdapterView(allOf(withId(R.id.listView),
                        childAtPosition(withId(R.id.main_content), 0))).atPosition(1);
        appCompatTextView.perform(click());
        getAdIdlingResource = SimpleCountingIdlingResource.create("test2");
        Log.i(TAG, "threadId=" + Thread.currentThread().getId() + ",processName=" + Thread
                .currentThread().getName());
        Espresso.registerIdlingResources(getAdIdlingResource);

    }

    @Test
    @RepeatRule.Repeat( runCount = Constants.TEST_COUNT)
    public void execute() {
        onView(withId(R.id.load_one)).perform(click());
        Log.i(TAG, "广告访问成功");
        onView(allOf(withId(R.id.container), isDisplayed())).check(ViewAssertions.matches
                (hasChildCount(1)));
    }

    @After
    public void stop() {
        Espresso.unregisterIdlingResources(getAdIdlingResource);
    }


    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }

}
